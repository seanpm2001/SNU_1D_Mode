module.exports = {
    extends: ['scratch'], // no ES6
    env: {
        worker: true
    },
    globals: {
        Scratch: true
    }
};
