module.exports = {
    extends: ['scratch', 'scratch/node']
};
